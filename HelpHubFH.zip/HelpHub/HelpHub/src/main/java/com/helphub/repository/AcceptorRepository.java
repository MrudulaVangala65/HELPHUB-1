package com.helphub.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.helphub.model.Acceptor;

public interface AcceptorRepository extends JpaRepository<Acceptor, Long> {
}
