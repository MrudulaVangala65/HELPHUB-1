package com.helphub.service;

import com.helphub.model.Acceptor;
import com.helphub.repository.AcceptorRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AcceptorService {

    @Autowired
    private AcceptorRepository repository;

    public Acceptor saveRequest(Acceptor request) {
        return repository.save(request);
    }

	public List<Acceptor> getByNeeds(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public void updateStatus(Long acceptorId, Object object) {
		// TODO Auto-generated method stub
		
	}

	public List<Acceptor> getByNeeds(List<String> categories) {
		// TODO Auto-generated method stub
		return null;
	}

    // Add more service methods here in the future (e.g., findById, listAll, delete, etc.)
}
