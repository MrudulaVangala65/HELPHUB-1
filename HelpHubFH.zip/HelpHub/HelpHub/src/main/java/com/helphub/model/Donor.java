package com.helphub.model;

import jakarta.persistence.*;

@Entity
public class Donor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDonorName() {
		return donorName;
	}
	public void setDonorName(String donorName) {
		this.donorName = donorName;
	}
	public String getDonorPhoneNum() {
		return donorPhoneNum;
	}
	public void setDonorPhoneNum(String donorPhoneNum) {
		this.donorPhoneNum = donorPhoneNum;
	}
	public String getDonorGPSLocation() {
		return donorGPSLocation;
	}
	public void setDonorGPSLocation(String donorGPSLocation) {
		this.donorGPSLocation = donorGPSLocation;
	}
	public String getNeeds() {
		return needs;
	}
	public void setNeeds(String needs) {
		this.needs = needs;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	private String donorName;
    private String donorPhoneNum;
    private String donorGPSLocation;
    private String needs;
    private String status = "Pending";

    // Getters and Setters
    // ...
}