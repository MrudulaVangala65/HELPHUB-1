package com.helphub.repository;

import com.helphub.model.Donor;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


public interface DonorRepository extends JpaRepository<Donor, Long> {
    List<Donor> findByNeedsContaining(String needs);
}