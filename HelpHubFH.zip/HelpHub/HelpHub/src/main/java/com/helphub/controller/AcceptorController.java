package com.helphub.controller;

import com.helphub.model.Acceptor;
import com.helphub.repository.AcceptorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/acceptor")
@CrossOrigin(origins = "*")
public class AcceptorController {

    @Autowired
    private AcceptorRepository repository;

    @PostMapping("/request")
    public ResponseEntity<Acceptor> createRequest(@RequestBody Acceptor request) {
        Acceptor savedRequest = repository.save(request);
        return ResponseEntity.ok(savedRequest);
    }

    static class ResponseMessage {
        public Long id;
        public ResponseMessage(Long id) {
            this.id = id;
        }
    }
}
