package com.helphub.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.helphub.model.Acceptor;
import com.helphub.model.Donor;
import com.helphub.service.AcceptorService;
import com.helphub.service.DonorService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/donors")
@CrossOrigin
public class DonorController {

    @Autowired
    private DonorService donorService;

    @Autowired
    private AcceptorService acceptorService;

    @PostMapping
    public Donor create(@RequestBody Donor donor) {
        return donorService.save(donor);
    }

    @GetMapping
    public List<Donor> list() {
        return donorService.getAll();
    }

    @PostMapping("/match")
    public List<Acceptor> getMatchingAcceptors(@RequestBody Map<String, List<String>> body) {
        List<String> categories = body.get("categories");
        return acceptorService.getByNeeds(categories);
    }

    @PutMapping("/donor/{donorId}/status")
    public Donor updateStatus(
            @PathVariable Long donorId,
            @RequestParam String status,
            @RequestParam Long acceptorId) {

        Donor updatedDonor = donorService.updateStatus(donorId, status);
        acceptorService.updateStatus(acceptorId, status.equalsIgnoreCase("Accept") ? "Accepted" : "Denied");
        return updatedDonor;
    }
 // ✅ Get all Acceptor requests needing "clothes" specifically
    @GetMapping("/requests/need/food")
    public List<Acceptor> getClothesRequests() {
        return acceptorService.getByNeeds("food");
    }
    
    // ✅ Get all Acceptor requests needing "clothes" specifically
    @GetMapping("/requests/need/books")
    public List<Acceptor> getBooksRequests() {
        return acceptorService.getByNeeds("books");
    }
    
    // ✅ Get all Acceptor requests needing "clothes" specifically
    @GetMapping("/requests/need/clothes")
    public List<Acceptor> getFoodRequests() {
        return acceptorService.getByNeeds("clothes");
    }


    @PutMapping("/{id}/status")
    public Donor updateStatus(@PathVariable Long id, @RequestParam String status) {
        return donorService.updateStatus(id, status);
    }

    @GetMapping("/need/{need}")
    public List<Donor> getByNeed(@PathVariable String need) {
        return donorService.getByNeeds(need);
    }
}