package com.helphub.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.helphub.model.Donor;
import com.helphub.repository.DonorRepository;

@Service
public class DonorService {

    @Autowired
    private DonorRepository repository;

    public Donor save(Donor donor) {
        return repository.save(donor);
    }

    public List<Donor> getAll() {
        return repository.findAll();
    }

    public Donor updateStatus(Long id, String status) {
        Donor donor = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Donor not found"));
        donor.setStatus(status);
        return repository.save(donor);
    }

    public List<Donor> getByNeeds(String needs) {
        return repository.findByNeedsContaining(needs);
    }
}